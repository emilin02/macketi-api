# ============================================================
# SCHEMAS DE AUTENTICACIÓN
# ============================================================

from pydantic import BaseModel, EmailStr, Field

from app.schemas.user import UserRead


class LoginRequest(BaseModel):
    """Cuerpo del POST /auth/login."""
    email: EmailStr
    password: str = Field(min_length=1)


class TokenResponse(BaseModel):
    """Respuesta del login."""
    access_token: str
    token_type: str = "bearer"
    user: UserRead